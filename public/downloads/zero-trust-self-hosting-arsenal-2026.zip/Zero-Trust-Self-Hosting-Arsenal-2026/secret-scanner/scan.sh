#!/bin/bash
# ClawGuru Zero-Trust Arsenal 2026
# Lokaler Secret Scanner - findet versehentlich committete Geheimnisse
# Aufruf: bash scan.sh /pfad/zu/projekt

SCAN_DIR="${1:-.}"
REPORT_FILE="/tmp/secret-scan-report-$(date +%Y%m%d_%H%M%S).html"
FOUND=0

echo "🔍 ClawGuru Secret Scanner starte..."
echo "   Scanne: $SCAN_DIR"

# Patterns die auf Secrets hinweisen
PATTERNS=(
  "password\s*=\s*['"][^'"]{4,}"
  "passwd\s*=\s*['"][^'"]{4,}"
  "secret\s*=\s*['"][^'"]{8,}"
  "api_key\s*=\s*['"][^'"]{8,}"
  "access_key\s*=\s*['"][^'"]{8,}"
  "private_key"
  "BEGIN RSA PRIVATE KEY"
  "BEGIN EC PRIVATE KEY"
  "BEGIN OPENSSH PRIVATE KEY"
  "AKIA[0-9A-Z]{16}"
  "sk-[a-zA-Z0-9]{48}"
  "xox[baprs]-[0-9a-zA-Z]{10,}"
  "ghp_[0-9a-zA-Z]{36}"
  "glpat-[0-9a-zA-Z_-]{20}"
)

# HTML Report Header
cat > "$REPORT_FILE" << 'HTMLEOF'
<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>ClawGuru Secret Scan Report</title>
<style>body{font-family:monospace;background:#0a0a0a;color:#e5e7eb;padding:2rem}
h1{color:#22d3ee}.finding{background:#1f2937;border:1px solid #374151;
border-radius:0.5rem;padding:1rem;margin:0.5rem 0}
.sev-high{border-left:4px solid #ef4444}
.file{color:#f59e0b}.line{color:#6b7280}.match{color:#f87171}</style>
</head><body>
<h1>🔍 ClawGuru Secret Scan Report</h1>
HTMLEOF

echo "<p>Scan-Zeitpunkt: $(date)</p><p>Verzeichnis: $SCAN_DIR</p><hr>" >> "$REPORT_FILE"

# Ausgeschlossene Pfade
EXCLUDE="--exclude-dir=.git --exclude-dir=node_modules --exclude-dir=vendor --exclude-dir=.venv"

for pattern in "${PATTERNS[@]}"; do
  while IFS= read -r line; do
    if [[ -n "$line" ]]; then
      FOUND=$((FOUND+1))
      file=$(echo "$line" | cut -d: -f1)
      linenum=$(echo "$line" | cut -d: -f2)
      content=$(echo "$line" | cut -d: -f3-)
      # Wert maskieren für Report
      safe_content=$(echo "$content" | sed 's/["'][^"']*["']/[REDACTED]/g')
      echo "<div class='finding sev-high'>"
      echo "<div class='file'>📁 $file:$linenum</div>"
      echo "<div class='match'>⚠️ Pattern: $pattern</div>"
      echo "<div class='line'>$safe_content</div>"
      echo "</div>"
    fi
  done < <(grep -rnP "$pattern" $EXCLUDE "$SCAN_DIR" 2>/dev/null | head -20) >> "$REPORT_FILE"
done

echo "<hr><p>Gefunden: $FOUND potenzielle Secrets.</p>" >> "$REPORT_FILE"
echo "</body></html>" >> "$REPORT_FILE"

echo ""
echo "✅ Scan abgeschlossen!"
echo "   Potenzielle Secrets: $FOUND"
echo "   Report: $REPORT_FILE"
[[ $FOUND -gt 0 ]] && echo "⚠️  WARNUNG: Mögliche Secrets gefunden! Report prüfen."
