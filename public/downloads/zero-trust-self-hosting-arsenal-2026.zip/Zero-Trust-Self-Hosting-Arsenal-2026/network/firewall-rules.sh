#!/bin/bash
# ClawGuru Zero-Trust Arsenal 2026
# Netzwerk-Segmentierung + Firewall Rulesets

# iptables-basiertes Zero-Trust Setup
# WARNUNG: Teste zuerst in einer VM/Test-Umgebung!

# Standard-Policy: ALLES blockieren
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Loopback erlauben
iptables -A INPUT -i lo -j ACCEPT

# Established connections erlauben
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# SSH (Rate-limited: max 5 neue Verbindungen pro Minute)
iptables -A INPUT -p tcp --dport 22 -m state --state NEW \
  -m recent --set --name SSH
iptables -A INPUT -p tcp --dport 22 -m state --state NEW \
  -m recent --update --seconds 60 --hitcount 5 --name SSH -j DROP
iptables -A INPUT -p tcp --dport 22 -j ACCEPT

# HTTP/HTTPS
iptables -A INPUT -p tcp -m multiport --dports 80,443 -j ACCEPT

# ICMP (ping) erlauben
iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT

# Docker Isolation (inter-container communication sperren)
iptables -I DOCKER-ISOLATION-STAGE-1 -j DROP

echo "✅ Firewall-Regeln aktiv"
iptables -L -v -n
