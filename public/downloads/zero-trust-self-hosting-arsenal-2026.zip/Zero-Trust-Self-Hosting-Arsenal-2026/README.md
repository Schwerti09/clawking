# Zero-Trust Self-Hosting Arsenal 2026

**Enterprise-Toolkit, jetzt kostenlos für Self-Hoster**
ClawGuru Security Team · v1.0 · April 2026

## Inhalt

| Ordner | Beschreibung |
|--------|---|
| `security-check/` | Offline-fähiger ClawGuru Live Security Check (HTML+JS) |
| `nuclei-templates/` | 8 spezialisierte Nuclei Templates für Self-Hosting |
| `nmap-scripts/` | Nmap NSE Scripts für Self-Hosting Security |
| `vault-templates/` | Vault + Bitwarden + Passkey Templates |
| `network/` | Netzwerk-Segmentierung + Firewall Rulesets |
| `secret-scanner/` | Lokaler Secret Scanner (Shell Script) |

## Schnellstart Offline Security Check

1. `security-check/index.html` im Browser öffnen
2. Deine Domain / IP eingeben
3. Ergebnis sofort sehen (keine Internet-Verbindung nötig)

## Nuclei Templates starten

```bash
# Nuclei installieren (falls nicht vorhanden)
go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest

# Alle ClawGuru Templates scannen
nuclei -t nuclei-templates/ -u https://your-domain.com -o results.txt
```

## Secret Scanner starten

```bash
chmod +x secret-scanner/scan.sh
bash secret-scanner/scan.sh /pfad/zu/projekt > secrets-report.html
```

## Rechtlicher Hinweis
Nur für eigene Systeme. Nicht für fremde Server.
Mehr: https://clawguru.org/de/securitycheck
