# ClawGuru Zero-Trust Arsenal 2026
# HashiCorp Vault Policies

# Policy: App kann nur eigene Secrets lesen
path "secret/data/myapp/*" {
  capabilities = ["read"]
}

# Policy: CI/CD kann Secrets rotieren
path "secret/data/myapp/db-credentials" {
  capabilities = ["read", "create", "update"]
}

# Policy: Admin darf alles
path "secret/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}

path "sys/mounts/*" {
  capabilities = ["create", "read", "update", "delete", "list"]
}
