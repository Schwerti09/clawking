# Entscheidungsbaum: Erst-Triage bei Security Incident
ClawGuru Warfare Manual 2026

## START: Alarm erhalten / Anomalie festgestellt

```
                         [ALARM / ANOMALIE]
                               |
                    Hast du Zugriff auf das System?
                         |              |
                        JA             NEIN
                         |              |
                    Sofort pruefen    Notfallkontakt
                         |            aktivieren
                         |
          Was ist das primaere Symptom?
          |         |         |         |
     [Hohe CPU]  [Netzwerk] [Login-  [Dateien
                 [Anomalie] [Fehler]  geaendert]
          |         |         |         |
       Crypto-  Exfiltrat. Brute-    Ransomware/
       Miner?   / C2-Shell? Force?   Tampering?
          |         |         |         |
      PB-03      PB-05    PB-01      PB-18
```

## Schweregrad-Bewertung

| Kriterium | Niedrig | Mittel | Hoch | Kritisch |
|-----------|---------|--------|------|----------|
| Daten betroffen | Nein | Moeglich | Ja | PII/Secrets |
| Service-Ausfall | Nein | Degradiert | Ja | Komplett |
| Persistence | Nein | Unklar | Ja | Backdoor |
| Ausbreitung | Lokal | 1 System | Mehrere | Alle |

## Sofortmassnahmen nach Schweregrad

### NIEDRIG (Score 1-3)
```bash
# Nur beobachten, Logs sammeln
bash ../forensics-scripts/collect-evidence.sh
```

### MITTEL (Score 4-6)
```bash
# Betroffenen Service isolieren
# Backup-Integritaet pruefen
bash ../forensics-scripts/full-forensics.sh
```

### HOCH / KRITISCH (Score 7-10)
1. System SOFORT vom Netz trennen
2. Management informieren
3. Passwort-Reset ALLER Accounts
4. Forensische Sicherung VOR Wiederherstellung
5. Evtl. externen IR-Dienstleister kontaktieren
