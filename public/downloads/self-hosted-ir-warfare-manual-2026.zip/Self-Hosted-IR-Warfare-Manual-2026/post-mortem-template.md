# Post-Mortem Template
ClawGuru Warfare Manual 2026

---
**Incident-ID:** [FILL: INC-2026-XXX]
**Datum:** [FILL]
**Autor:** [FILL]
**Status:** [Draft / Review / Abgeschlossen]

---

## Zusammenfassung (1-2 Saetze)
[Was ist passiert, was war die Auswirkung?]

## Timeline

| Zeitpunkt | Ereignis | Wer |
|-----------|----------|-----|
| T+00:00 | Incident erkannt | [Person/System] |
| T+00:xx | [Naechster Schritt] | |
| T+xx:xx | Incident resolved | |

## Auswirkungen

- Betroffene Systeme: [Liste]
- Betroffene Nutzer: [Anzahl / Beschreibung]
- Datenverlust: [Ja/Nein / Beschreibung]
- Service-Ausfall: [Dauer]
- Finanzielle Auswirkung: [Schaetzung]

## Root Cause Analysis (5 Whys)

1. Warum ist der Incident passiert?
   → [Antwort]
2. Warum war das so?
   → [Antwort]
3. Warum war das so?
   → [Antwort]
4. Warum war das so?
   → [Antwort]
5. Warum war das so (Root Cause)?
   → **[ROOT CAUSE]**

## Was lief gut
- [Positive Punkte: Was hat die Reaktion verbesserrt?]

## Was lief schlecht
- [Negative Punkte: Was hat die Reaktion verzoegert?]

## Action Items

| Massnahme | Prioritaet | Owner | Faellig |
|-----------|-----------|-------|---------|
| [Massnahme 1] | HOCH | [Person] | [Datum] |
| [Massnahme 2] | MITTEL | [Person] | [Datum] |

## Verbesserungen am Monitoring
- [ ] Neuer Alert definiert fuer: [Bedingung]
- [ ] Dashboard aktualisiert

## Lessons Learned
[3-5 Bullet Points - Was nimmt das Team mit?]

---
Naechstes Review: [Datum]
ClawGuru IR: https://clawguru.org/de/moltbot/incident-response-automation
