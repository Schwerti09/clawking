# Checkliste: Kritischer Sicherheitsvorfall
ClawGuru Warfare Manual 2026

## ERSTE 15 MINUTEN (Golden Window)

### Sofortmassnahmen
- [ ] System-Zustand sichern (collect-evidence.sh starten)
- [ ] Screenshot / Foto der aktuellen Systemmeldungen
- [ ] Incident-Ticket eroeffnen (Zeit, erste Beobachtungen)
- [ ] On-Call-Person informieren

### Einschaetzen
- [ ] Welche Systeme sind betroffen?
- [ ] Gibt es Anzeichen fuer Daten-Exfiltration?
- [ ] Besteht aktive Angreifer-Verbindung?
- [ ] Backups vorhanden und unbeschaaedigt?

### Entscheidung: Isolieren?
- [ ] System vom Netz trennen (wenn aktiver Angriff) ODER
- [ ] Monitoring verstaerken (wenn nur Verdacht)

## ERSTE STUNDE

### Eindaemmung
- [ ] Verdaechtige IPs blockieren (iptables)
- [ ] Betroffene Accounts sperren
- [ ] Service-Keys rotieren (sofort!)
- [ ] Management informieren (wenn PII betroffen: DSGVO 72h!)

### Analyse
- [ ] Einstiegspunkt identifiziert?
- [ ] Timeline des Angriffs skizziert?
- [ ] Schadensumfang bekannt?

## DSGVO-MELDEPFLICHT

Bei Datenpannen mit personenbezogenen Daten:
- 72 Stunden: Meldung an zustaendige Behoerde (Datenschutzbehoerde)
- Betroffene Personen informieren (wenn hohes Risiko)
- Dokumentation des Vorfalls (4 Jahre aufbewahren)

Mehr: https://clawguru.org/de/moltbot/compliance-gdpr-setup
