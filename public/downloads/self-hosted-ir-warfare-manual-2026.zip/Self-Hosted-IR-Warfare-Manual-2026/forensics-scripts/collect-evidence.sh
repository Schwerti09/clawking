#!/bin/bash
# ClawGuru Warfare Manual 2026
# collect-evidence.sh - Forensik-Beweise sichern
# Aufruf: sudo bash collect-evidence.sh [output-dir]

OUTPUT_DIR="${1:-/forensics/evidence-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$OUTPUT_DIR"

echo "========================================="
echo "  ClawGuru Forensics Evidence Collector"
echo "  Output: $OUTPUT_DIR"
echo "========================================="

collect() {
    local name="$1"
    local cmd="$2"
    echo "  Sammle: $name..."
    eval "$cmd" > "$OUTPUT_DIR/$name" 2>&1 || true
}

# System-Zustand
collect "01-system-info.txt" "uname -a && uptime && date && hostname"
collect "02-running-processes.txt" "ps auxww --forest"
collect "03-network-connections.txt" "ss -tunapl"
collect "04-open-files.txt" "lsof 2>/dev/null | head -1000"
collect "05-logged-in-users.txt" "w && who && last | head -50"
collect "06-crontabs.txt" "for u in \$(cut -d: -f1 /etc/passwd); do echo "=== \$u ==="; crontab -u \$u -l 2>/dev/null; done"
collect "07-listening-ports.txt" "ss -tlnp"
collect "08-docker-status.txt" "docker ps -a 2>/dev/null"
collect "09-docker-images.txt" "docker images 2>/dev/null"
collect "10-env-variables.txt" "env"

# Logs
collect "logs-auth.txt" "cat /var/log/auth.log 2>/dev/null || journalctl _COMM=sshd -n 1000 2>/dev/null"
collect "logs-syslog.txt" "cat /var/log/syslog 2>/dev/null || journalctl -n 1000 2>/dev/null"
collect "logs-nginx.txt" "tail -1000 /var/log/nginx/access.log 2>/dev/null"
collect "logs-nginx-error.txt" "tail -500 /var/log/nginx/error.log 2>/dev/null"

# Benutzer & Berechtigungen
collect "11-passwd.txt" "cat /etc/passwd"
collect "12-sudoers.txt" "cat /etc/sudoers 2>/dev/null"
collect "13-ssh-authorized-keys.txt" "find /home /root -name authorized_keys -exec echo '=== {} ===' \; -exec cat {} \; 2>/dev/null"
collect "14-suid-files.txt" "find / -perm -4000 -type f 2>/dev/null"
collect "15-world-writable.txt" "find / -perm -o+w -type f 2>/dev/null | head -100"

# Hash des Evidence-Ordners fuer Integritaet
find "$OUTPUT_DIR" -type f -exec sha256sum {} \; > "$OUTPUT_DIR/MANIFEST.sha256"

echo ""
echo "Gesammelte Beweise: $(ls $OUTPUT_DIR | wc -l) Dateien"
echo "Manifest: $OUTPUT_DIR/MANIFEST.sha256"
echo ""
echo "WICHTIG: Output-Ordner SOFORT auf externen Speicher sichern!"
