#!/bin/bash
# ClawGuru Warfare Manual 2026
# memory-dump.sh - Speicher-Dump fuer Forensik
# Erfordert: avml oder fmem (oder LiME)

OUTPUT_DIR="${1:-/forensics}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DUMP_FILE="$OUTPUT_DIR/memory-dump-$TIMESTAMP.lime"

mkdir -p "$OUTPUT_DIR"

echo "Memory Dump Tool fuer Linux Forensik"
echo ""
echo "Option 1: Mit avml (empfohlen)"
echo "  wget https://github.com/microsoft/avml/releases/download/v0.6.1/avml"
echo "  chmod +x avml"
echo "  sudo ./avml $DUMP_FILE"
echo ""
echo "Option 2: /proc/kcore (rudimentaer)"
echo "  sudo dd if=/proc/kcore of=$OUTPUT_DIR/kcore-$TIMESTAMP.raw bs=1M"
echo ""
echo "Option 3: LiME Kernel Module"
echo "  sudo insmod lime-$(uname -r).ko path=$DUMP_FILE format=lime"
echo ""
echo "Analyse mit Volatility3:"
echo "  python3 vol.py -f $DUMP_FILE linux.pslist"
echo "  python3 vol.py -f $DUMP_FILE linux.netstat"
echo ""
echo "Mehr: https://clawguru.org/de/moltbot/incident-response-automation"
