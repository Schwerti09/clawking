#!/bin/bash
# ClawGuru Warfare Manual 2026
# full-forensics.sh - Vollstaendige forensische Analyse

OUTPUT_DIR="${1:-/forensics/full-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$OUTPUT_DIR"

echo "Starte vollstaendige Forensik..."

# Basis-Evidence sammeln
bash "$(dirname "$0")/collect-evidence.sh" "$OUTPUT_DIR"

# Zusaetzliche Tiefenanalyse
echo "  Analyse: Kuerzlich geaenderte Dateien..."
find / -newer /etc/passwd -not -path "/proc/*" -not -path "/sys/*"   -not -path "/dev/*" -type f 2>/dev/null | head -200 > "$OUTPUT_DIR/recently-modified-files.txt"

echo "  Analyse: Verdaechtige Netzwerk-Verbindungen..."
ss -tunapl | grep -v "127.0.0.1\|::1" | grep ESTABLISHED > "$OUTPUT_DIR/external-connections.txt"

echo "  Analyse: Kernel-Module..."
lsmod > "$OUTPUT_DIR/kernel-modules.txt"

echo "  Analyse: Geladene Bibliotheken verdaechtiger Prozesse..."
for pid in $(ps -eo pid,pcpu --sort=-pcpu | head -20 | tail -19 | awk '{print $1}'); do
    echo "=== PID $pid ===" >> "$OUTPUT_DIR/process-maps.txt"
    cat /proc/$pid/maps 2>/dev/null >> "$OUTPUT_DIR/process-maps.txt"
done

echo ""
echo "Vollstaendige Forensik abgeschlossen: $OUTPUT_DIR"
