# IR Playbook: Docker Container Escape
ClawGuru Warfare Manual 2026

**Severity:** Hoch bis Kritisch
**Erkennungszeit (MTTD):** < 15 Minuten (mit Monitoring)
**Reaktionszeit (MTTR):** 1-4 Stunden

---

## Phase 1: Erkennung & Triage (< 5 Minuten)

**Alarmsignale:**
Host-Prozesse, Capabilities, Mount-Points

**Sofortmassnahme:**
```bash
# Systemstatus verschaffen
uptime && w && ps aux --sort=-%cpu | head -20
netstat -tunapl | grep ESTABLISHED | head -30
last | head -20
```

## Phase 2: Eindaemmung (< 30 Minuten)

### Schritt 1: Analyse
```bash
# Auth-Logs pruefen
grep -E "Failed|Invalid|error" /var/log/auth.log | tail -50

# Verdaechtige Prozesse
ps aux | grep -v "\[" | awk '{print $1,$2,$3,$11}' | sort -k3 -rn | head -20

# Netzwerk-Verbindungen
ss -tunapl | grep ESTABLISHED
```

### Schritt 2: Bedrohung isolieren
```bash
# Verdaechtige Verbindung trennen (IP anpassen!)
# iptables -A INPUT -s ANGREIFER_IP -j DROP
# iptables -A OUTPUT -d ANGREIFER_IP -j DROP
echo "REPLACE_ANGREIFER_IP with actual IP before running!"
```

### Schritt 3: Evidence sichern
```bash
# Forensische Kopie erstellen
mkdir -p /forensics/evidence-$(date +%Y%m%d-%H%M%S)
cp /var/log/auth.log /forensics/evidence-$(date +%Y%m%d-%H%M%S)/
cp /var/log/syslog /forensics/evidence-$(date +%Y%m%d-%H%M%S)/
ps auxww > /forensics/evidence-$(date +%Y%m%d-%H%M%S)/processes.txt
netstat -tunapl > /forensics/evidence-$(date +%Y%m%d-%H%M%S)/netstat.txt
```

## Phase 3: Analyse (1-2 Stunden)

1. Timeline des Angriffs rekonstruieren
2. Einstiegspunkt identifizieren
3. Betroffene Systeme/Daten identifizieren
4. Schadensmass bewerten

## Phase 4: Wiederherstellung

```bash
# System-Integritaet pruefen
debsums -c  # Debian/Ubuntu: geaenderte System-Dateien
rpm -Va     # CentOS/RHEL: geaenderte Packages

# Passwort-Reset fuer alle Accounts
for user in $(cat /etc/passwd | cut -d: -f1); do
    chage -d 0 $user 2>/dev/null
done
```

## Phase 5: Post-Incident

- [ ] Post-Mortem erstellen (Template: ../post-mortem-template.md)
- [ ] Root Cause identifiziert?
- [ ] Verbesserungen implementiert?
- [ ] Stakeholder informiert?
- [ ] Monitoring-Regel hinzugefuegt?

---
ClawGuru IR Automation: https://clawguru.org/de/moltbot/incident-response-automation
