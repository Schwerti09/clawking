# Self-Hosted Incident Response Warfare Manual 2026
Echte Kriegshandbuecher fuer Self-Hoster – keine generischen Templates
ClawGuru Security Team v1.0 April 2026

## Inhalt
| Ordner | Beschreibung |
|--------|---|
| playbooks/ | 18 Incident Response Playbooks (Markdown) |
| decision-trees/ | Entscheidungsbaeume fuer Erst-Triage |
| post-mortem-template.md | Post-Mortem Template |
| forensics-scripts/ | Forensik-Scripts (Log Extraction, Evidence Collection) |
| checklists/ | Schnell-Checklisten fuer den Ernstfall |

## Im Ernstfall
1. Entscheidungsbaum aufmachen: decision-trees/01-initial-triage.md
2. Passendes Playbook auswaehlen
3. Schritt fuer Schritt ausfuehren
4. Post-Mortem DANACH erstellen

Mehr: https://clawguru.org/de/moltbot/incident-response-automation
