#!/bin/bash
# ClawGuru Fortress Blueprint 2026
# 02-ssh-hardening.sh - SSH Härtung

set -euo pipefail
[[ $EUID -ne 0 ]] && { echo "❌ Root-Rechte erforderlich!"; exit 1; }

echo "🔐 SSH-Härtung..."

# SSH Config sichern
cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak.$(date +%Y%m%d)

# Hardening Config
cat > /etc/ssh/sshd_config.d/99-hardening.conf << 'EOF'
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
LoginGraceTime 30
X11Forwarding no
AllowTcpForwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
TCPKeepAlive no
Compression no
UseDNS no
EOF

# Konfiguration testen
sshd -t && echo "✅ SSH Config OK"
systemctl restart sshd

echo "✅ SSH-Härtung abgeschlossen!"
