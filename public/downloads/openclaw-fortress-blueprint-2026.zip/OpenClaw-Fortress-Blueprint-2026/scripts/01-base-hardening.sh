#!/bin/bash
# ClawGuru Fortress Blueprint 2026
# 01-base-hardening.sh - Basis-Systemhärtung (Ubuntu/Debian)
# Aufruf: sudo bash 01-base-hardening.sh

set -euo pipefail

echo "========================================="
echo "  ClawGuru Fortress Blueprint 2026"
echo "  01 - Basis-Systemhärtung"
echo "========================================="

# Root-Check
[[ $EUID -ne 0 ]] && { echo "❌ Root-Rechte erforderlich!"; exit 1; }

# System aktualisieren
echo "📦 System aktualisieren..."
apt-get update -qq && apt-get upgrade -y -qq

# Sicherheitstools installieren
echo "🛠️  Sicherheitstools installieren..."
apt-get install -y -qq ufw fail2ban unattended-upgrades apt-listchanges   auditd audispd-plugins rkhunter chkrootkit lynis

# Automatische Updates konfigurieren
echo "🔄 Automatische Sicherheitsupdates..."
dpkg-reconfigure --priority=low unattended-upgrades -f noninteractive

# Kernel-Parameter härten
echo "⚙️  Kernel-Parameter härten..."
cat >> /etc/sysctl.d/99-security.conf << 'EOF'
# Network Security
net.ipv4.conf.default.rp_filter=1
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.all.accept_redirects=0
net.ipv6.conf.all.accept_redirects=0
net.ipv4.conf.all.send_redirects=0
net.ipv4.conf.all.accept_source_route=0
net.ipv6.conf.all.accept_source_route=0
net.ipv4.icmp_echo_ignore_broadcasts=1
net.ipv4.icmp_ignore_bogus_error_responses=1
net.ipv4.tcp_syncookies=1
net.ipv4.tcp_max_syn_backlog=2048

# Kernel Security
kernel.randomize_va_space=2
kernel.dmesg_restrict=1
kernel.kptr_restrict=2
fs.protected_hardlinks=1
fs.protected_symlinks=1
EOF
sysctl --system -q

echo "✅ Basis-Härtung abgeschlossen!"
echo ""
echo "Nächste Schritte:"
echo "  bash 02-ssh-hardening.sh"
echo "  bash 03-firewall-setup.sh"
