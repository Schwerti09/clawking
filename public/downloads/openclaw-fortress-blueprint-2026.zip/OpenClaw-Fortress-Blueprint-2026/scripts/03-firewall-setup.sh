#!/bin/bash
# ClawGuru Fortress Blueprint 2026
# 03-firewall-setup.sh - UFW Firewall Setup

set -euo pipefail
[[ $EUID -ne 0 ]] && { echo "❌ Root-Rechte erforderlich!"; exit 1; }

echo "🔥 Firewall-Setup..."

apt-get install -y -qq ufw

ufw --force reset
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'SSH'
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'
ufw limit ssh comment 'SSH Rate-Limit'
ufw --force enable

echo "✅ Firewall aktiv!"
ufw status verbose
