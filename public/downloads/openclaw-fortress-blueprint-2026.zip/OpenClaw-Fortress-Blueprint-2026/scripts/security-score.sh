#!/bin/bash
# ClawGuru Fortress Blueprint 2026
# security-score.sh - Lokaler Security-Score (0-100)

score=0
max=100
issues=()

echo "========================================="
echo "  ClawGuru Local Security Score"
echo "========================================="
echo ""

check() {
  local desc="$1"; local cmd="$2"; local pts="$3"
  if eval "$cmd" &>/dev/null; then
    echo "  ✅ $desc (+$pts)"
    score=$((score + pts))
  else
    echo "  ❌ $desc (0/$pts)"
    issues+=("$desc")
  fi
}

echo "🔐 SSH Security:"
check "Root-Login deaktiviert" "grep -q 'PermitRootLogin no' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf 2>/dev/null" 10
check "Passwort-Auth deaktiviert" "grep -q 'PasswordAuthentication no' /etc/ssh/sshd_config /etc/ssh/sshd_config.d/*.conf 2>/dev/null" 15

echo ""
echo "🔥 Firewall:"
check "UFW aktiv" "ufw status | grep -q 'Status: active'" 15
check "Standard: deny incoming" "ufw status verbose | grep -q 'Default: deny (incoming)'" 10

echo ""
echo "🐳 Docker:"
check "Docker Daemon: no-new-privileges" "docker info 2>/dev/null | grep -q 'no-new-privileges'" 10
check "Docker Socket gesichert" "[[ $(stat -c '%G' /var/run/docker.sock 2>/dev/null) == 'docker' ]]" 10

echo ""
echo "📦 Updates:"
check "Automatische Updates aktiv" "systemctl is-active unattended-upgrades &>/dev/null" 10
check "System aktuell (<7 Tage)" "[[ $(find /var/cache/apt -name 'pkgcache.bin' -mtime -7 | wc -l) -gt 0 ]]" 10

echo ""
echo "🛡️  Security Tools:"
check "Fail2Ban aktiv" "systemctl is-active fail2ban &>/dev/null" 10

echo ""
echo "========================================="
printf "  SECURITY SCORE: %d/%d
" "$score" "$max"
echo "========================================="

if [[ ${#issues[@]} -gt 0 ]]; then
  echo ""
  echo "⚠️  Offene Punkte:"
  for issue in "${issues[@]}"; do
    echo "  → $issue"
  done
fi

echo ""
echo "🌐 Vollständiger Online-Scan: https://clawguru.org/de/securitycheck"
