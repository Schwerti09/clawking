# OpenClaw Security-Checkliste 2026

**ClawGuru Fortress Blueprint 2026 · Tier-basiertes Scoring**

---

## 🟢 Tier 1 — Basis (Pflicht für alle)

### Server Basis
- [ ] SSH: Root-Login deaktiviert (`PermitRootLogin no`)
- [ ] SSH: Passwort-Auth deaktiviert (`PasswordAuthentication no`)
- [ ] SSH: Ed25519-Keys eingerichtet
- [ ] Firewall: UFW aktiv, default deny incoming
- [ ] Firewall: Nur Port 22, 80, 443 offen
- [ ] Updates: Unattended-upgrades aktiviert
- [ ] Fail2Ban: Konfiguriert für SSH + Nginx

### Docker Basis
- [ ] Docker: `no-new-privileges` in daemon.json
- [ ] Docker: icc=false (inter-container communication)
- [ ] Docker: Container als non-root User
- [ ] Docker: Images von vertrauenswürdigen Quellen
- [ ] Docker: Trivy-Scans in CI/CD

### Tier 1 Score: __ / 12 Punkte

---

## 🟡 Tier 2 — Produktiv

### Secrets
- [ ] Keine .env-Dateien in Git
- [ ] Alle Secrets in Vault / Umgebungsvariablen
- [ ] Regelmäßiger Secret-Rotation-Prozess
- [ ] .gitignore: .env, *.pem, *.key

### TLS/HTTPS
- [ ] Let's Encrypt Zertifikate (auto-renewal)
- [ ] TLS 1.2+ only (TLS 1.0/1.1 deaktiviert)
- [ ] HSTS Header mit preload
- [ ] SSL Labs Score: A+

### Monitoring
- [ ] Prometheus + Grafana aktiviert
- [ ] Alerts für fehlgeschlagene Logins
- [ ] Log-Retention konfiguriert (min. 90 Tage)
- [ ] Uptime-Monitoring (UptimeRobot / Betterstack)

### Tier 2 Score: __ / 12 Punkte

---

## 🔴 Tier 3 — Business-kritisch

### Zero-Trust
- [ ] Netzwerk-Segmentierung mit Docker Networks
- [ ] mTLS zwischen Services
- [ ] RBAC für alle Admin-Zugriffe
- [ ] Least-Privilege-Prinzip durchgesetzt

### Compliance
- [ ] DSGVO: Datenschutzerklärung aktuell
- [ ] Audit-Log: Alle Admin-Aktionen protokolliert
- [ ] Regelmäßige Backups (3-2-1-Regel)
- [ ] Backup-Restore-Tests dokumentiert
- [ ] IR-Plan vorhanden und getestet

### Tier 3 Score: __ / 9 Punkte

---

## 📊 Gesamt-Security-Score

| Tier | Punkte | Max |
|------|--------|-----|
| Tier 1 | | 12 |
| Tier 2 | | 12 |
| Tier 3 | | 9 |
| **Gesamt** | | **33** |

**Bewertung:**
- 25-33: 🏆 Exzellent
- 18-24: ✅ Gut
- 10-17: ⚠️ Verbesserungsbedarf
- 0-9:   ❌ Kritisch — sofort handeln!

**Kostenloser Online Security Check:** https://clawguru.org/de/securitycheck
