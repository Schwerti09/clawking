# Runbook: SSH Hardening

**Ziel:** SSH-Server gegen Brute-Force und unauthorized access absichern
**Schwierigkeit:** ⭐⭐ Mittel
**Zeit:** ~15 Minuten

## Vorbedingungen
- Root oder sudo-Zugang
- SSH Key bereits konfiguriert (BEVOR du PasswordAuthentication deaktivierst!)

## Schritte

### Schritt 1: SSH-Key generieren (falls nicht vorhanden)
```bash
ssh-keygen -t ed25519 -C "admin@meinserver" -f ~/.ssh/id_ed25519
ssh-copy-id -i ~/.ssh/id_ed25519.pub user@server
```

### Schritt 2: SSH Config härten
```bash
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak
sudo tee /etc/ssh/sshd_config.d/hardening.conf << 'EOF'
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
LoginGraceTime 30
X11Forwarding no
AllowTcpForwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
EOF
```

### Schritt 3: Konfiguration testen & anwenden
```bash
sudo sshd -t && sudo systemctl restart sshd
```

## Verifizierung
```bash
ssh -o PasswordAuthentication=no user@server "echo OK"
```

## Rollback
```bash
sudo cp /etc/ssh/sshd_config.bak /etc/ssh/sshd_config
sudo systemctl restart sshd
```
