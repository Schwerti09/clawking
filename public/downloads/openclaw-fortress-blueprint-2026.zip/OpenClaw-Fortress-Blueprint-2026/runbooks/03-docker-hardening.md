# Runbook: Docker Daemon Hardening

**Ziel:** Docker Daemon gegen Container-Escapes und unautorisierten Zugriff sichern
**Schwierigkeit:** ⭐⭐ Mittel
**Zeit:** ~20 Minuten

## Docker Daemon konfigurieren

```bash
sudo tee /etc/docker/daemon.json << 'EOF'
{
  "icc": false,
  "no-new-privileges": true,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "live-restore": true,
  "userland-proxy": false,
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    }
  }
}
EOF

sudo systemctl daemon-reload
sudo systemctl restart docker
```

## Docker Socket absichern

```bash
# Docker Socket gehört root:docker - NIEMALS world-writeable!
ls -la /var/run/docker.sock
# Erwartet: srw-rw---- 1 root docker

# Überprüfen wer in der docker Gruppe ist
getent group docker
```

## Container Security Scanner

```bash
# Trivy: Container Images auf Schwachstellen scannen
docker run --rm -v /var/run/docker.sock:/var/run/docker.sock \
  aquasec/trivy image --severity HIGH,CRITICAL nginx:latest
```

## Verifizierung

```bash
# icc (inter-container communication) testen
docker network inspect bridge | grep -i icc
# Erwartet: "com.docker.network.bridge.enable_icc": "false"
```
