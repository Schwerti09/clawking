# Runbook: UFW Firewall Setup

**Ziel:** Netzwerkzugang mit UFW einschränken
**Schwierigkeit:** ⭐ Einfach
**Zeit:** ~10 Minuten

## Grundkonfiguration

```bash
# UFW installieren
sudo apt install -y ufw

# Default-Regeln
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Notwendige Ports öffnen
sudo ufw allow 22/tcp comment 'SSH'
sudo ufw allow 80/tcp comment 'HTTP'
sudo ufw allow 443/tcp comment 'HTTPS'

# UFW aktivieren
sudo ufw enable

# Status prüfen
sudo ufw status verbose
```

## Rate-Limiting für SSH

```bash
sudo ufw limit ssh comment 'SSH Rate Limit'
```

## Logging aktivieren

```bash
sudo ufw logging medium
sudo tail -f /var/log/ufw.log
```

## Nützliche Befehle

```bash
# Alle Regeln anzeigen (nummeriert)
sudo ufw status numbered

# Regel löschen (Nummer aus status numbered)
sudo ufw delete 3

# Temporär deaktivieren (KEIN Neustart-Schutz!)
sudo ufw disable
```
