# Runbook: SSL/TLS Hardening

**Ziel:** TLS-Konfiguration auf A+ Rating bringen (SSL Labs)
**Schwierigkeit:** ⭐⭐⭐ Fortgeschritten
**Zeit:** ~30 Minuten

## Let's Encrypt mit Certbot

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d example.com -d www.example.com
```

## Nginx TLS-Konfiguration

```nginx
# /etc/nginx/conf.d/ssl.conf
ssl_protocols TLSv1.2 TLSv1.3;
ssl_prefer_server_ciphers off;
ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;
ssl_session_timeout 1d;
ssl_session_cache shared:MozSSL:10m;
ssl_session_tickets off;
ssl_stapling on;
ssl_stapling_verify on;
resolver 8.8.8.8 1.1.1.1 valid=300s;
resolver_timeout 5s;
```

## HSTS Header

```nginx
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
```

## SSL-Score prüfen

```bash
# Online: https://www.ssllabs.com/ssltest/
# Lokal:
docker run --rm drwetter/testssl.sh --fast https://example.com
```
