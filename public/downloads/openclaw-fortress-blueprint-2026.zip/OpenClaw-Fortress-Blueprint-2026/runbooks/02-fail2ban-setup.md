# Runbook: Fail2Ban Setup

**Ziel:** Automatisches Bannen von Brute-Force-Angreifern
**Schwierigkeit:** ⭐ Einfach
**Zeit:** ~10 Minuten

## Installation

```bash
sudo apt update && sudo apt install -y fail2ban
sudo systemctl enable fail2ban
```

## Konfiguration

```bash
sudo tee /etc/fail2ban/jail.local << 'EOF'
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 5

[sshd]
enabled  = true
port     = ssh
maxretry = 3
bantime  = 86400

[nginx-http-auth]
enabled  = true
port     = http,https
filter   = nginx-http-auth
logpath  = /var/log/nginx/error.log

[nginx-botsearch]
enabled  = true
port     = http,https
filter   = nginx-botsearch
logpath  = /var/log/nginx/access.log
maxretry = 2
EOF

sudo systemctl restart fail2ban
```

## Status prüfen

```bash
sudo fail2ban-client status
sudo fail2ban-client status sshd
```

## Gebannte IPs anzeigen / entsperren

```bash
# Alle gebannten IPs
sudo fail2ban-client status sshd | grep "Banned IP"

# IP entsperren
sudo fail2ban-client set sshd unbanip 1.2.3.4
```
