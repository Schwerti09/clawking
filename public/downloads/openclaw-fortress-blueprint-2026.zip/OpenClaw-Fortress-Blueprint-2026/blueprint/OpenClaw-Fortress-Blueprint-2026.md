# OpenClaw Fortress Blueprint 2026
## Das vollständige Hardening-Framework für Self-Hoster

**ClawGuru Security Team · Version 1.0 · April 2026**

---

## Kapitel 1: Systemvoraussetzungen & Threat Model

### 1.1 Threat Model für Self-Hosting

Bevor du anfängst, definiere dein Bedrohungsmodell:

**Typische Bedrohungen für Self-Hoster:**
- Automated bots & credential stuffing (>80% aller Angriffe)
- Exposed admin panels (Portainer, phpMyAdmin, Traefik Dashboard)
- Unpatched CVEs in Docker Images (NVD/OSV-Scanner Pflicht)
- Secrets in .env-Dateien / Git-History
- Misconfigured reverse proxies (path traversal, SSRF)
- Supply chain attacks via Docker Hub images

### 1.2 Security Tiers

| Tier | Beschreibung | Empfohlen für |
|------|---|---|
| 🟢 Tier 1 | Basis-Hardening (firewall, fail2ban, SSH-Keys) | Alle Self-Hoster |
| 🟡 Tier 2 | Container-Isolation + Secrets Management | Produktive Services |
| 🔴 Tier 3 | Zero-Trust + mTLS + Audit Logging | Business-kritische Systeme |

---

## Kapitel 2: Server-Basis-Hardening (Ubuntu/Debian)

### 2.1 SSH-Härtung

```bash
# /etc/ssh/sshd_config
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
MaxAuthTries 3
LoginGraceTime 30
AllowUsers deploy admin
Protocol 2
X11Forwarding no
AllowTcpForwarding no
ClientAliveInterval 300
ClientAliveCountMax 2
```

### 2.2 UFW Firewall Basis-Konfiguration

```bash
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp comment 'SSH'
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'
ufw enable
ufw status verbose
```

### 2.3 Fail2Ban Konfiguration

```ini
# /etc/fail2ban/jail.local
[DEFAULT]
bantime  = 3600
findtime = 600
maxretry = 5
backend  = systemd

[sshd]
enabled = true
port    = ssh
filter  = sshd
logpath = /var/log/auth.log
maxretry = 3
bantime = 86400

[nginx-http-auth]
enabled  = true
port     = http,https
filter   = nginx-http-auth
logpath  = /var/log/nginx/error.log

[nginx-botsearch]
enabled  = true
port     = http,https
filter   = nginx-botsearch
logpath  = /var/log/nginx/access.log
maxretry = 2
```

---

## Kapitel 3: Docker Security Hardening

### 3.1 Docker Daemon sichern

```json
// /etc/docker/daemon.json
{
  "icc": false,
  "no-new-privileges": true,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "userns-remap": "default",
  "live-restore": true,
  "userland-proxy": false,
  "default-ulimits": {
    "nofile": {
      "Name": "nofile",
      "Hard": 64000,
      "Soft": 64000
    }
  }
}
```

### 3.2 Container-Security-Checkliste

```yaml
# Sichere docker-compose Service-Konfiguration
services:
  myapp:
    image: myapp:latest
    read_only: true                    # Filesystem read-only
    security_opt:
      - no-new-privileges:true         # Keine Privilege Escalation
      - apparmor:docker-default        # AppArmor Profil
    cap_drop:
      - ALL                            # Alle Capabilities entfernen
    cap_add:
      - NET_BIND_SERVICE               # Nur benötigte hinzufügen
    user: "1000:1000"                  # Non-root User
    tmpfs:
      - /tmp:size=50m,mode=1777        # Beschreibbares tmpfs
    environment:
      - SECRET=${SECRET_FROM_VAULT}    # Secrets aus Vault, nie hardcoded
    networks:
      - internal                       # Isoliertes Netzwerk
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "-qO-", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
```

---

## Kapitel 4: Traefik Reverse Proxy Hardening

### 4.1 Traefik Security Headers

```yaml
# traefik.yml
api:
  insecure: false
  dashboard: false    # NIEMALS öffentlich zugänglich!

entryPoints:
  web:
    address: ":80"
    http:
      redirections:
        entryPoint:
          to: websecure
          scheme: https
  websecure:
    address: ":443"
    http:
      tls:
        options: secure@file

tls:
  options:
    secure:
      minVersion: VersionTLS12
      cipherSuites:
        - TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384
        - TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384
        - TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256
        - TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256
        - TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256
        - TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256
      sniStrict: true
```

---

## Kapitel 5: Nginx Security Hardening

### 5.1 Security Headers

```nginx
# /etc/nginx/conf.d/security-headers.conf
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'nonce-{NONCE}'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self'; frame-ancestors 'none';" always;
add_header Permissions-Policy "geolocation=(), microphone=(), camera=(), payment=(), usb=(), magnetometer=(), gyroscope=()" always;
add_header X-XSS-Protection "1; mode=block" always;
```

---

## Kapitel 6: Secrets Management

### 6.1 Grundregeln

**NIEMALS in Git committen:**
- `.env` Dateien mit echten Credentials
- API-Keys, Passwörter, Zertifikate
- SSH Private Keys
- Database Connection Strings mit Passwort

### 6.2 .env.example Pattern

```bash
# .env.example (DIESES in Git, NIE .env)
DATABASE_URL=postgresql://user:CHANGE_ME@localhost:5432/dbname
REDIS_URL=redis://:CHANGE_ME@localhost:6379
JWT_SECRET=CHANGE_ME_min_32_chars
API_KEY=CHANGE_ME
```

### 6.3 Vault-Integration (HashiCorp Vault)

```bash
# Vault Secret lesen
export MY_SECRET=$(vault kv get -field=value secret/myapp/api-key)

# Docker: Secrets aus Vault injizieren
docker run -e SECRET="$(vault kv get -field=value secret/myapp/secret)" myapp
```

---

## Kapitel 7: Monitoring & Alerting

### 7.1 Prometheus Node Exporter

```yaml
# docker-compose.monitoring.yml
services:
  node-exporter:
    image: prom/node-exporter:latest
    command:
      - '--path.procfs=/host/proc'
      - '--path.rootfs=/rootfs'
      - '--path.sysfs=/host/sys'
      - '--collector.filesystem.mount-points-exclude=^/(sys|proc|dev|host|etc)($$|/)'
    volumes:
      - /proc:/host/proc:ro
      - /sys:/host/sys:ro
      - /:/rootfs:ro
    networks:
      - monitoring
    restart: unless-stopped

  alertmanager:
    image: prom/alertmanager:latest
    volumes:
      - ./alertmanager.yml:/etc/alertmanager/alertmanager.yml
    networks:
      - monitoring
    restart: unless-stopped
```

### 7.2 Kritische Prometheus Alerts

```yaml
# alerts/security.yml
groups:
  - name: security
    rules:
      - alert: HighFailedLoginRate
        expr: rate(nginx_http_requests_total{status="401"}[5m]) > 10
        for: 2m
        labels:
          severity: warning
        annotations:
          summary: "Hohe Rate fehlgeschlagener Logins"

      - alert: UnusualOutboundTraffic
        expr: rate(node_network_transmit_bytes_total[5m]) > 10000000
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Ungewöhnlicher Outbound-Traffic - mögliche Exfiltration"

      - alert: ContainerPrivilegeEscalation
        expr: container_last_seen{security_opt="no-new-privileges:false"} == 1
        labels:
          severity: critical
        annotations:
          summary: "Container ohne no-new-privileges Einschränkung"
```

---

## Kapitel 8: Backup & Recovery

### 8.1 3-2-1 Backup Regel

```
3 Kopien der Daten
2 verschiedene Speichermedien
1 offsite/remote Backup
```

### 8.2 Automatisches Postgres Backup

```bash
#!/bin/bash
# scripts/backup-postgres.sh
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/postgres"
DB_NAME="myapp"
RETENTION_DAYS=30

mkdir -p $BACKUP_DIR

# Backup erstellen
docker exec postgres pg_dump -U postgres $DB_NAME | gzip > "$BACKUP_DIR/${DB_NAME}_${DATE}.sql.gz"

# Alte Backups löschen
find $BACKUP_DIR -name "*.sql.gz" -mtime +$RETENTION_DAYS -delete

# Backup verifizieren
if [ $? -eq 0 ]; then
    echo "✅ Backup erfolgreich: ${DB_NAME}_${DATE}.sql.gz"
else
    echo "❌ Backup fehlgeschlagen!"
    # Alert senden
    curl -X POST "$ALERTING_WEBHOOK" -d '{"text": "❌ Postgres Backup fehlgeschlagen!"}'
fi
```

---

*Ende des OpenClaw Fortress Blueprint 2026 · ClawGuru Security Team*
*Für Live Security Scans: https://clawguru.org/de/securitycheck*
