# Kill Chain: 07-privilege-escalation

## Beschreibung
Rechteausweitung im Multi-Agent-System

## Kill Chain Schritte
1. Recon - Schwachstelle identifizieren
2. Weaponization - Payload vorbereiten
3. Delivery - Ueber User-Input / API einschleusen
4. Exploitation - Angriff ausfuehren
5. Actions on Objective - Ziel erreicht

## Gegenmaassnahmen
Agent AuthN, Least-Privilege

## Referenzen
- MITRE ATLAS: https://atlas.mitre.org/
- OWASP LLM Top 10: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- ClawGuru: https://clawguru.org/de/moltbot/ai-agent-security
