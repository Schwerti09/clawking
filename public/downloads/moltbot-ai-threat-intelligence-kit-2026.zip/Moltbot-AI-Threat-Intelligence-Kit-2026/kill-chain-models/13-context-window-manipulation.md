# Kill Chain: 13-context-window-manipulation

## Beschreibung
Context Window mit Noise ueberfuellen

## Kill Chain Schritte
1. Recon - Schwachstelle identifizieren
2. Weaponization - Payload vorbereiten
3. Delivery - Ueber User-Input / API einschleusen
4. Exploitation - Angriff ausfuehren
5. Actions on Objective - Ziel erreicht

## Gegenmaassnahmen
Context-Management, Relevanz-Filtering

## Referenzen
- MITRE ATLAS: https://atlas.mitre.org/
- OWASP LLM Top 10: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- ClawGuru: https://clawguru.org/de/moltbot/ai-agent-security
