# Kill Chain: 01-reconnaissance

## Beschreibung
Angreifer sammelt Infos ueber das AI-System

## Kill Chain Schritte
1. Recon - Schwachstelle identifizieren
2. Weaponization - Payload vorbereiten
3. Delivery - Ueber User-Input / API einschleusen
4. Exploitation - Angriff ausfuehren
5. Actions on Objective - Ziel erreicht

## Gegenmaassnahmen
Rate-Limiting, API-Monitoring, Anonymisierung

## Referenzen
- MITRE ATLAS: https://atlas.mitre.org/
- OWASP LLM Top 10: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- ClawGuru: https://clawguru.org/de/moltbot/ai-agent-security
