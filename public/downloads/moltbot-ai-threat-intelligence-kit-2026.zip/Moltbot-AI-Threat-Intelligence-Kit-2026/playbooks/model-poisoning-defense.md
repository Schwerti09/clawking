# Playbook: Model-Poisoning Defense
ClawGuru AI Security 2026

## Was ist Model Poisoning?
Supply-Chain-Angriff auf AI-Modelle via vergiftete Trainingsdaten.

## Erkennungszeichen
- Modell verhaelt sich bei Trigger-Phrases anders
- Bias in Outputs fuer bestimmte Themen
- Unerwartete Tool-Calls bei speziellen Inputs

## Gegenmaassnahmen

### 1. Vendor Assessment Checkliste
- [ ] SOC 2 Type II Zertifizierung
- [ ] Bug-Bounty-Programm vorhanden
- [ ] Transparenzbericht verfuegbar
- [ ] Daten-Verarbeitungsvertrag (DPA)
- [ ] DSGVO-konform

### 2. Behavioral Testing
```python
def test_model_behavior(model, test_cases):
    for input_text, expected_output in test_cases:
        actual = model.generate(input_text)
        assert expected_output in actual
```

### 3. Fallback-Modelle konfigurieren
```yaml
ai_providers:
  primary:
    provider: openai
    model: gpt-4o
  fallback:
    provider: anthropic
    model: claude-3-5-sonnet
  emergency:
    provider: local
    model: llama-3-8b
```

Mehr: https://clawguru.org/de/moltbot/ai-agent-threat-model
