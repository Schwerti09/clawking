# AI Agent Threat Model — STRIDE Analysis
ClawGuru Security Team 2026

## System Overview
- Agent Name: [FILL]
- Model: [FILL: e.g. GPT-4o, Gemini 2.5]
- Deployment: [FILL: Self-hosted / Cloud]
- Trust Level: [FILL: Internal / External / Untrusted]

## STRIDE Threats

### S — Spoofing
| Threat | Risiko | Massnahme |
|--------|--------|-----------|
| System-Prompt Injection via User-Input | KRITISCH | Input-Sanitization |
| Fake Tool-Calls | HOCH | Tool-Signaturen HMAC |
| Agent-Identity Spoofing | MITTEL | mTLS + JWT |

### T — Tampering
| Threat | Risiko | Massnahme |
|--------|--------|-----------|
| Prompt-Injection via externe Daten | KRITISCH | Alle Daten escapen |
| Model-Poisoning | HOCH | Supply Chain Assessment |
| Tool-Parameter-Manipulation | HOCH | JSON Schema Validation |

### I — Information Disclosure
| Threat | Risiko | Massnahme |
|--------|--------|-----------|
| System-Prompt-Exfiltration | KRITISCH | Konfidentiell markieren |
| PII-Leakage in Outputs | HOCH | PII-Detektion |
| Credentials im Context | KRITISCH | Secrets NIE im Prompt |

### D — Denial of Service
| Threat | Risiko | Massnahme |
|--------|--------|-----------|
| Token-Stuffing / Flooding | HOCH | Max-Token-Limit |
| Infinite-Loop-Injection | MITTEL | Max-Iterations-Limit |

### E — Elevation of Privilege
| Threat | Risiko | Massnahme |
|--------|--------|-----------|
| Jailbreaking Safety-Filter | KRITISCH | Multi-Layer Safety |
| Tool-Privilege-Escalation | KRITISCH | Least-Privilege + Sandbox |

## Checkliste
- [ ] Alle KRITISCHEN Threats adressiert?
- [ ] Threat Model reviewed?
- [ ] Security Tests in CI/CD?

ClawGuru: https://clawguru.org/de/moltbot/ai-agent-threat-model
