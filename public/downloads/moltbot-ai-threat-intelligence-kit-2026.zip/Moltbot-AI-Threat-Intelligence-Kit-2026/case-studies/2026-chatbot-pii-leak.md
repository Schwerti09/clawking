# Case Study: Customer Service Chatbot PII Leak
Jahr: 2026 | ClawGuru Security Analysis

## Zusammenfassung
Kundenservice-Chatbot gab nach Jailbreaking PII anderer Kunden preis.

## Was passierte
Angreifer nutzten Rollenspiel-Prompts um Daten aus dem geteilten
Context Window zu extrahieren (Memory-Sharing-Bug).

## Root Causes
1. Geteilter Context zwischen Nutzer-Sessions
2. Kein Output-Scanning auf PII
3. Safety-Filter zu leicht umgehbar

## Lektionen
- Strikte Session-Isolation (kein shared memory)
- PII-Redaktion im Output-Layer
- Regelmaessige Jailbreak-Tests

Mehr: https://clawguru.org/de/moltbot/ai-agent-security
