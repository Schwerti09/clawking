# Moltbot & AI Agent Threat Intelligence Kit 2026
ClawGuru Security Team v1.0 April 2026

Inhalt:
- threat-model/ - STRIDE Threat Model Template
- kill-chain-models/ - 14 AI-Agent Kill Chain Modelle
- runbook-generator/ - Automatischer Runbook Generator
- playbooks/ - Defense Playbooks
- case-studies/ - Real-World Case Studies 2025/2026

Mehr: https://clawguru.org/de/moltbot/ai-agent-threat-model
