#!/bin/bash
# ClawGuru AI Runbook Generator 2026
# Usage: bash generate.sh <threat-type> <agent-name>
# Example: bash generate.sh prompt-injection moltbot

THREAT="${1:-prompt-injection}"
AGENT="${2:-moltbot}"
DATE=$(date +%Y-%m-%d)
OUTFILE="${DATE}-${AGENT}-${THREAT}-runbook.md"

cat > "$OUTFILE" << RUNBOOK
# IR Runbook: ${THREAT} auf ${AGENT}
Generiert: ${DATE} | ClawGuru AI Runbook Generator

## Erkennungsphase
1. Logs pruefen: grep -i "injection" /var/log/${AGENT}/requests.log
2. Metriken pruefen: Auffaellige Token-Mengen?
3. Anomalie-Score pruefen im Monitoring-Dashboard

## Eingrenzungsphase
4. Betroffene Session sperren
5. Rate-Limiting verschaerfen
6. Payload sichern fuer forensische Analyse

## Analyse
7. Request-Payload analysieren
8. Model-Output auf Exfiltration pruefen
9. Timeline erstellen

## Beseitigung
10. Injection-Pattern zur Blocklist hinzufuegen
11. Service neu starten
12. Monitoring-Alert definieren

## Post-Incident
13. Post-Mortem erstellen
14. Verbesserungen implementieren
15. Naechstes Review-Datum setzen

---
ClawGuru AI Security: https://clawguru.org/de/moltbot/incident-response-automation
RUNBOOK

echo "Runbook erstellt: $OUTFILE"
